class Stagiaire{
    constructor(nom, prenom){
        this.nom = nom.toUpperCase();
        this.prenom = prenom;
    }

    salutation(){
        console.log(`Bonjour, je suis ${this.prenom} ${this.nom}`);
    }
}