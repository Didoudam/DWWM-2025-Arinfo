
var classe;

window.addEventListener("DOMContentLoaded", () =>{
    document.querySelector("#btnCreerClasse").addEventListener("click", creerClasse);
    document.querySelector("#btnAjouter").addEventListener("click", ajouterStagiaire);
});

function creerClasse(){
    let intitule = document.querySelector("#intitule").value;
    let dateDebut = document.querySelector("#dateDebut").value;
    let dateFin = document.querySelector("#dateFin").value;

    classe = new Classe(intitule, dateDebut, dateFin);
    console.log("Classe créée : ", classe);

    document.querySelector("#formStagiaire").style.display = "block";
    afficherClasse();
}

function ajouterStagiaire(){
    let prenom = document.querySelector("#prenom").value;
    let nom = document.querySelector("#nom").value;
    let stagiaire = new Stagiaire(prenom, nom);
    
    classe.ajoutStagiaire(stagiaire);
    afficherClasse();
    mettreAJourSelect();
}

function afficherClasse(){
    let affichage = `<b>${classe.intitule}</b><br>`;
    affichage += `Du ${classe.dateDebut.toLocaleDateString()} au ${classe.dateFin.toLocaleDateString()}<br>`;
    affichage += "<u>Liste des stagiaires :</u><br>";
    affichage += classe.listeStagiaires.map(stagiaire => `- ${stagiaire.prenom} ${stagiaire.nom}`).join('<br>');

    document.querySelector("#affichage").innerHTML = affichage;
    console.log(classe);
        
}

function mettreAJourSelect(){
    let select = document.querySelector("#listeStagaires");
    select.innerHTML = ""; // Vider le select avant de le remplir
    classe.listeStagiaires.forEach(stagiaire => {
        let option = document.createElement("option");
        option.textContent = `${stagiaire.prenom} ${stagiaire.nom}`;
        select.appendChild(option);
    });
}