class Classe{
    constructor(intitule, dateDebut, dateFin){
        this.intitule = intitule;
        this.dateDebut = new Date(dateDebut);
        this.dateFin = new Date(dateFin);
        this.listeStagiaires = [];
    }

    ajoutStagiaire(stagiaire){
        this.listeStagiaires.push(stagiaire);
    }
}